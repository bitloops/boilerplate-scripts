import { IamRepository } from './IamRepository';

export default IamRepository;
