import AuthLayoutController from './AuthLayoutController';

export default AuthLayoutController;
