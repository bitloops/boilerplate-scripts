import TodoEntry from './TodoEntryController';

export default TodoEntry;
