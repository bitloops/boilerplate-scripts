import TodoPanel from './TodoPanelController';

export default TodoPanel;
