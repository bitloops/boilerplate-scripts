import Login from './controller';

export default Login;
