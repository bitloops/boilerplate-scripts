// import SimpleButton from '../../components/Buttons/SimpleButton';
// import Image404 from '../../assets/404.svg';
// import returnIcon from '../../assets/return.svg';

function NotFoundPage(): JSX.Element {
  return <div>404 - Page not found</div>;
}
export default NotFoundPage;
