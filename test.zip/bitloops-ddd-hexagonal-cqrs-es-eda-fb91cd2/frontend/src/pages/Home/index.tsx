import HomePage from './page';

export default HomePage;
