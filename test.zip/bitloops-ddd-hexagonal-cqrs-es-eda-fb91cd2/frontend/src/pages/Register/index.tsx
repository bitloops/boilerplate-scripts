import Register from './controller';

export default Register;
