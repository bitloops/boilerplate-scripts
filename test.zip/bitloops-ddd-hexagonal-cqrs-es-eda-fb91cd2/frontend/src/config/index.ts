export const AUTH_URL = process.env.AUTH_URL || 'http://localhost:8082/auth/login';
export const PROXY_URL = process.env.PROXY_URL || 'http://localhost:8080';
export const REGISTRATION_URL =
  process.env.REGISTRATION_URL || 'http://localhost:8082/auth/register';
