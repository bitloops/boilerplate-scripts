export const StreamingIntegrationEventBusToken = Symbol(
  'StreamingIntegrationEventBusToken',
);
export const StreamingDomainEventBusToken = Symbol(
  'StreamingDomainEventBusToken',
);

export const UserWriteRepoPortToken = Symbol('UserWriteRepoPort');
