export interface RegisterCommandDTO {
  email: string;
  password: string;
}
