export interface ChangeEmailCommandDTO {
  email: string;
  userId: string;
}
