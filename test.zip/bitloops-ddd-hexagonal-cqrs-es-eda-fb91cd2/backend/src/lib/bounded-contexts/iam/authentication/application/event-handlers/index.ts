import { StreamingDomainEventHandlers } from './domain';

export const EventHandlers = [...StreamingDomainEventHandlers];
