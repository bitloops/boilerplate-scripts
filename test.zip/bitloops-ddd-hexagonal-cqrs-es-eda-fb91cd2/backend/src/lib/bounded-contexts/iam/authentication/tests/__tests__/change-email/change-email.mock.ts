export const CHANGE_EMAIL_SUCCESS_CASE = {
  id: '123',
  email: 'newUser@bitloops.com',
  password: 'test',
};

export const INVALID_EMAIL_CASE = {
  id: '123',
  email: 'newUserbitloops.com',
  password: 'test',
};

export const USER_REPO_ERROR_GETBYID_CASE = {
  id: '1234',
  email: 'newUser@bitloops.com',
  password: 'test',
};
export const USER_NOT_FOUND_CASE = {
  id: '12345',
  email: 'newUser@bitloops.com',
  password: 'test',
};

export const USER_REPO_ERROR_UPDATE_CASE = {
  id: '123456',
  email: 'newUser@bitloops.com',
  password: 'test',
};
