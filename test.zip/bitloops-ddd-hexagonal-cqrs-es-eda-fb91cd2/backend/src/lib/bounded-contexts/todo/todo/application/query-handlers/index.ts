import { GetTodosHandler } from './get-todos.handler';

export const QueryHandlers = [GetTodosHandler];
