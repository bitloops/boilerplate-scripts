import { StreamingDomainEventHandlers } from './domain';

export const StreamingErrorEventHandlers = [];
export const EventHandlers = [...StreamingDomainEventHandlers];
