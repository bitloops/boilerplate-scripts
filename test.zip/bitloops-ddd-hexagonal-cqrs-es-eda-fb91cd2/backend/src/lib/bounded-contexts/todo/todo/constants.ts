export const StreamingCommandBusToken = Symbol('StreamingCommandBusToken');
export const StreamingIntegrationEventBusToken = Symbol(
  'StreamingIntegrationEventBusToken',
);
export const PubSubIntegrationEventBusToken = Symbol(
  'PubSubIntegrationEventBusToken',
);
export const StreamingDomainEventBusToken = Symbol('StreamingDomainEventBus');

export const TodoWriteRepoPortToken = Symbol('TodoWriteRepoPort');

export const TodoReadRepoPortToken = Symbol('TodoReadRepoPort');
