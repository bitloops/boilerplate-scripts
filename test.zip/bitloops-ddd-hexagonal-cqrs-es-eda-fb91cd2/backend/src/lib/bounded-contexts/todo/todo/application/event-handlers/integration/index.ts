export const StreamingIntegrationEventHandlers = [];
