export const ADD_TODO_SUCCESS_CASE = {
  title: 'new title',
  userId: '123',
  completed: false,
};

export const ADD_TODO_INVALID_TITLE_CASE = {
  title: 'i',
  userId: '123',
};

export const ADD_TODO_REPO_ERROR_CASE = {
  title: 'new title',
  userId: '1234',
};
