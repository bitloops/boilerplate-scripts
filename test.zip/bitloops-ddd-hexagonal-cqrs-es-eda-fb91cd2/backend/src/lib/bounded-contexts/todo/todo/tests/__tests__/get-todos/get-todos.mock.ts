export const GET_TODOS_SUCCESS_CASE = {
  userId: '123',
  titleId: '1',
  title: 'todo title',
  completed: true,
};

export const GET_TODOS_EMPTY_ARRAY_CASE = {
  userId: '1234',
};

export const GET_TODOS_REPO_ERROR_CASE = {
  userId: '12345',
};
