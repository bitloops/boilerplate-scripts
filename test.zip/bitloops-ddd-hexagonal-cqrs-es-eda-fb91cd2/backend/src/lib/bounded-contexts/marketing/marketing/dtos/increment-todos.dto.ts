export interface IncrementTodosDTO {
    userId: string;
}