export type SendEmailRequest = {
  origin: string;
  destination: string;
  content: string;
};
