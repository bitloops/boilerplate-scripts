export const SUCCESS_CASE = {
  userId: '123',
  todoId: 'todo1',
};
