export const SUCCESS_CASE = {
  userId: '123',
  email: 'user@bitloops.com',
};
