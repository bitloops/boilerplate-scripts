export const UPDATE_USER_SUCCESS_CASE = {
  email: 'user@bitloops.com',
  userId: '123',
  completedTodos: 1,
};

export const UPDATE_USER_REPO_ERROR_CASE = {
  email: 'user2@bitloops.com',
  userId: '1234',
  completedTodos: 0,
};
