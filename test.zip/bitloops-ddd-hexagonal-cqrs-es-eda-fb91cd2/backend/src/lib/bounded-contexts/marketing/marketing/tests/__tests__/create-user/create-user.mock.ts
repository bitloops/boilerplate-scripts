export const CREATE_USER_SUCCESS_CASE = {
  email: 'user@bitloops.com',
  userId: '123',
  completedTodos: 0,
};

export const CREATE_USER_REPO_ERROR_CASE = {
  email: 'user2@bitloops.com',
  userId: '1234',
  completedTodos: 0,
};
