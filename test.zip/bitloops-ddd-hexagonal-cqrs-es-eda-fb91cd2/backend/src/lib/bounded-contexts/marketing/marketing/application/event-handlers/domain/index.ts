import { TodoCompletionsIncrementedHandler } from './todo-completions-incremented.handler';

export const StreamingDomainEventHandlers = [TodoCompletionsIncrementedHandler];
