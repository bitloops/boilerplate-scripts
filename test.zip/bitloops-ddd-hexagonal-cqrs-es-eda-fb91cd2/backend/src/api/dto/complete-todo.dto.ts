export interface CompleteTodoDto {
  todoId: string;
}
