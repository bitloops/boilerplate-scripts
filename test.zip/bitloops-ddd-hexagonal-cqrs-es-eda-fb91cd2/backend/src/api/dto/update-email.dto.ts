export interface UpdateEmailDTO {
  email: string;
}
