# Deploying on Kubernetes

Run the following script after making sure you have added the appropriate secrets to your configuration files located in the k8s folder:

```bash
./apply_k8s_files.sh
```
